  var firebaseConfig = {
    apiKey: "AIzaSyCvhaYfuEPtGnI7zDD9ItO2yWz8hfk5XBU",
    authDomain: "my-project-3a7fd.firebaseapp.com",
    databaseURL: "https://my-project-3a7fd-default-rtdb.firebaseio.com",
    projectId: "my-project-3a7fd",
    storageBucket: "my-project-3a7fd.appspot.com",
    messagingSenderId: "882502190452",
    appId: "1:882502190452:web:076c422e350374e154d821"
  };
 
  firebase.initializeApp(firebaseConfig);
